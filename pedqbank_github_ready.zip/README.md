# PedQBank — Pediatric Board Study App

Single-file, offline-capable HTML study app (1,045 questions, 21 topics, 54 comparative tables, flashcards, infographics, and an in-app question editor).

## Deploy to GitHub Pages (free, ~2 minutes)

1. Go to https://github.com/new and create a new repository (e.g. `pedqbank`). Keep it Public (GitHub Pages on free accounts requires a public repo, or use GitHub Pro/Team for a private one).
2. Click **Add file → Upload files**, drag in `index.html` from this folder, and commit.
3. Go to the repo's **Settings → Pages**.
4. Under "Build and deployment", set **Source: Deploy from a branch**, **Branch: main**, folder **/ (root)** → **Save**.
5. Wait ~1 minute, then your app is live at:
   `https://<your-username>.github.io/<repo-name>/`

## Updating later
Any time you want to push a new version (e.g. a fresh export from this chat), just re-upload `index.html` to the same repo (or drag-and-drop the new file — GitHub will ask to overwrite) and Pages redeploys automatically in under a minute.

## Notes on the in-app editor
- The "✏️ Edit" button on any question lets you correct the stem, options, correct answer, explanation, reference, or attach an image — saved to your browser's local storage.
- Because it's local storage, edits made by one visitor (e.g. you, on your phone) don't sync to other visitors or devices automatically.
- Use **⬇ Export edits** in the sidebar to download a small JSON file of your corrections, and **⬆ Import edits** to load it on another device/browser — or send me that file and I'll bake the corrections into the master copy for the next deploy.
